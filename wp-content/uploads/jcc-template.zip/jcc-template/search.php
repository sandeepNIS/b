<?php get_header(); ?>
	<div id="page">
		<div id="page-bgtop">
			<div id="page-bgbtm">
				<div id="content">
					<div class="post">
            <h2 class="searchtitle"> 検索結果
            </h2>
          </div>
					
					<?php if (have_posts()) : ?>
					<?php while (have_posts()) : the_post(); ?>
					<div class="post">
						
						<h2 class="title"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php search_title_highlight(); ?></a></h2>
						<p class="meta">
						<div class="entry">
							<?php // the_content('Read the rest of this entry &raquo;'); ?>
							<?php search_excerpt_highlight(); ?>
							<?php //the_content( $more_link_text, $stripteaser ); ?>
						</div>
					</div>
					<?php endwhile; ?>
					<?php else : ?>

					<h2>見つかりませんでした。</h2>
					<p>申し訳ありませんが、ここではない何かを探しています。</p>

					<?php endif; ?>
					
					<div style="clear: both;">&nbsp;</div>
				</div>
				<?php get_sidebar(); ?>
				<!-- end #content -->
				
				<div style="clear: both;">&nbsp;</div>
			</div>
		</div>
	</div>
	<!-- end #page -->
</div>


<?php get_footer(); ?>