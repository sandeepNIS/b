<?php require('./wp-load.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<title>News Ticker with jQuery</title>
<!-- Feel free to set any reference to jQuery library locally or to a CDN -->
<script src="<?php bloginfo('template_directory'); ?>/js/jquery-1.3.2.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	
	var speed = 700;
	var pause = 3500;
	
	function newsticker()
	{
	    // algorithm:
	    // get last element, remove it from the list,
	    // add to first position with hidden style
	    // slideDown the new first element
	    // continue
	    last = $('ul#listticker li:last').hide().remove();
	    $('ul#listticker').prepend(last);
        $('ul#listticker li:first').slideDown("slow");
	}
	
	interval = setInterval(newsticker, pause);
});
</script>
<style type="text/css">

#listticker{
	height:200px;
	width:650px;
	overflow:hidden;
	padding:6px 10px 24px 10px;;
	margin:0;
}
#listticker li{
	border:0; margin:0; padding:0; list-style:none;
}

	#listticker li{
		height:60px;
		padding:5px;
		list-style:none;
		
	}
		#listticker a{
			color:#000000;
			margin-bottom:
		}
		#listticker .news-title{
			display:block;
			font-weight:bold;
			margin:15px 0 0 100px;
			font-size:11px;
		}
		#listticker .news-text{
			display:block;
			font-size:11px;
			margin:5px 0 0 100px;
			color:#666666;
		}
		#listticker img{
			float:left;
			margin-right:14px;
			margin: 20px 0 10px -10px;
			/*padding:20px;
			border:solid 1px #DEDEDE;*/
		}
</style>

</head>

<body>
<ul id="listticker">
<?php
$posts = get_posts("numberposts=5&category=&orderby=post_date&offset=0");
foreach ($posts as $post):
  setup_postdata($post);
?>
<li><img src="<?php bloginfo('template_directory'); ?>/images/<?php $categories = get_the_category(); if ( !empty( $categories ) ) { echo $categories[0]->name; }else{ echo 'icon_news_1';} ?>.gif" width="70" height="18" border="0" /> <a href="<?php the_permalink(); ?>" class="news-title"><?php echo get_the_date(); ?></a> <span class="news-text"> <?php the_title(); ?> </span> </li>
<?php
endforeach; 
?>
</ul>
</body>
</html>
