<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>

<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<meta name="Content-Language" content="jp" />
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" >
<title><?php bloginfo('name'); ?> <?php if ( is_single() ) { ?> 
&raquo; <?php 
foreach((get_the_category()) as $cat) { 
echo $cat->cat_name . ' '; 
} ?> <?php } ?> 

<?php wp_title(); ?></title>

<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" /> <!-- leave this for stats --> 
<title><?php bloginfo('name'); ?> <?php if ( is_single() ) { ?> &raquo; Blog Archive <?php } ?> <?php wp_title(); ?></title>
<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_url'); ?>" media="screen" />
<!--[if IE ]>
<link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/iestyle.css" type="text/css" media="screen" />

<![endif]-->
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/jQery/jqueryslidemenu.css" />


<!--[if lte IE 7]>
<style type="text/css">
html .jqueryslidemenu{height: 1%;} /*Holly Hack for IE7 and below*/
</style>
<![endif]-->

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.2.6/jquery.min.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.3/jquery.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/jQery/jqueryslidemenu.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/jQery/unitpngfix.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/jQery/search/jquery.color.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/jQery/search/script.js"></script>
<script>
$(document).ready(function(){

	// hide #back-top first
	$("#back-top").hide();
	
	// fade in #back-top
	$(function () {
		$(window).scroll(function () {
			if ($(this).scrollTop() > 100) {
				$('#back-top').fadeIn();
			} else {
				$('#back-top').fadeOut();
			}
		});

		// scroll body to 0px on click
		$('#back-top a').click(function () {
			$('body,html').animate({
				scrollTop: 0
			}, 800);
			return false;
		});
	});

});

$(function() {
  $('#scroll-top').click(function() {
  $('body,html').animate({scrollTop:0},800);   
  });
});
</script>
<!--[if lt IE 7]>
        <script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/jQery/unitpngfix.js"></script>
<![endif]--> 
<?php wp_head(); ?>

</head>
<body>
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<!--<h1><a href="#">バンガロール商工会</a></h1>
			<p>The Japan Chamber of Commerce,  <a href="http://www.nichi.com/">Bangalore</a></p>-->
			<h1><img src="<?php bloginfo('template_directory'); ?>/images/logo.gif" alt="バンガロール商工会"  border="0"  /></h1>
		</div>
		<div id="search">
			<!--<form method="get" action="">

				<fieldset>

					<input type="text" name="id" id="search-text" size="15" value="ログインID" />

					<input type="password" name="pw" id="search-text" size="15" value="**********" />

					<input type="submit" id="search-submit" value="GO" />

				</fieldset>

			</form>-->
			<form id="searchForm"  method= "get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                <fieldset>
                    <div class="input">
                        <input type="text" name="s" id="s" value="検索" />
                    </div>
                    <input type="submit" id="searchSubmit" value="" />
                </fieldset>
            </form>

		</div>

	</div>
	<!-- end #header -->
	<!--<div id="menu">-->
		<div id="myslidemenu" class="jqueryslidemenu">
				<ul>
					<li <?php if(!is_page()) echo 'class="current_page_item"'; ?>><a href="<?php echo get_option('home'); ?>/">トップ
</a></li>
			<?php wp_list_pages('title_li=');  		?>
					 
				</ul>
				<br style="clear: left" /> 
				
</div>
		
<!--	</div>-->
	<!-- end #menu -->
	