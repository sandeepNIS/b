<?php get_header(); ?>
<div id="page">
		<div id="page-bgtop">
			<div id="page-bgbtm">
				<div id="content">
					<div id="header-flash">
							<img src="<?php bloginfo('template_directory'); ?>/images/banner.jpg" width="620" height="260" alt="banner" border="0" />
					</div>
          <div class="post">
						<h2 class="title1"><a href="#">バンガロールへようこそ！</a></h2>

						<!--<p class="meta">
							&nbsp;&bull;&nbsp; <a href="#">詳細を見る</a></p>-->
						<div class="entry">
							<p><img src="<?php bloginfo('template_directory'); ?>/images/img05.jpg" width="143" height="143" alt="" class="alignleft border" />
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;南インド、カルナータカ州の州都、<a href="http://www.nichi.com/">バンガロール</a>は、インドで、日本人にとって一番住みやすい町だといえるでしょう。
							とかく暑い、と思われがちなインド。けれども、この街は標高920mの高原にあり、気候は一年中穏やかです。
							こちらの夏は3月から5月ですが、日本の夏と比べると湿気がなく、部屋の中にいると、エアコンは必要ありません。12～1月の真冬でも、朝晩は冷え込みますが、暖房が要るほどではなく、昼間はTシャツで外が歩けます。
							また、南インドの人々は、総じて人なつっこく、目があうとにっこり笑ってくれ、付き合いやすい人たちです。
                           	</p>
							<p>
							この街の名前はある物語に由来します。1120年チョーラ王朝のヴィーラバララ2世が、狩をしていて、森に迷ってしまいました。そのとき、一人の貧しい女性が、空腹の彼に豆を煮て食べさせてくれました。彼は、この場所をカンナダ語で"Benda Kalooru(ベンダカルール＝煮豆の街)"と呼んだのでした。
                            </p>
							<p>

                            現在この街は、エアコンシティー、パブシティー、庭園都市、そしてインドのシリコンバレーなどと呼ばれています。
                            小さいけれどもモダンな街、<a href="http://www.nichi.com/">バンガロール</a>。ここは、日本人を含めて、外国人が、快適に過ごせるところです。
							</p>
						</div>
					</div>
					<div class="post">
						<h2 class="title1"><a href="http://nichiin.dynsite.net/~madan/wordpress/?page_id=219">最新情報</a></h2>
						<p class="meta">最新更新日：2011年12月27日
							&nbsp;&bull;&nbsp; <a href="http://nichiin.dynsite.net/~madan/wordpress/?page_id=219">一覧を見る
</a>

						</p>
						<div class="entry">
              <div id="newsmenu">
              
				<?php include (TEMPLATEPATH . '/newsticker.php'); ?>
				
  <br/>


     </div>
            </div>
          </div>
          <div style="clear: both;">&nbsp;</div>
        </div>
        <!-- end #content -->
        <!-- Sidebar-->

        <?php require_once('sidebar.php');?>

        <!-- end #sidebar -->
        <div style="clear: both;">&nbsp;</div>
      </div>
    </div>
  </div>
  <!-- end #page -->
  </div><?php get_footer(); ?>