<?php get_header(); ?>
	<div id="page">
		<div id="page-bgtop">
			<div id="page-bgbtm">
				<div id="content">
				
					
					<?php if (have_posts()) : ?>
					<?php while (have_posts()) : the_post(); ?>
					<div class="post">	
					<h2 class="title"><?php echo get_the_title(); ?> </h2>
						<div class="entry">
							<?php the_content('Read the rest of this entry &raquo;'); ?>
						</div>
					</div>
					<?php endwhile; ?>
					<?php else : ?>

					<h2>Not Found</h2>
					<p>Sorry, but you are looking for something that isn't here.</p>

					<?php endif; ?>
					
					<div style="clear: both;">&nbsp;</div>
				</div>
				<?php get_sidebar(); ?>
				<!-- end #content -->
				
				<div style="clear: both;">&nbsp;</div>
			</div>
		</div>
	</div>
	<!-- end #page -->
</div>


<?php get_footer(); ?>