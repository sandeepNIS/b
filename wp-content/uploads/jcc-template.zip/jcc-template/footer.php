	<div style="clear: both;">&nbsp;</div>
<div id="footer">
<div class="footer-content">
<a id="scroll-top" title="Scroll to Top"></a>
 <p> Copyright &#169; <?php echo date('Y'); ?> <?php bloginfo('name'); ?> - All Rights Reserved.
</p>
<p class="red">
Website Developed and Maintained by <a href="http://www.nichi.com/" target="_blank" title="By Nichi-in">Nichi-in Software Solutions. Pvt. Ltd.</a></p>
   <?php wp_footer(); ?></div>
  <div class="bottom"><span>&nbsp;</span></div>
</div>
</body>
</html>