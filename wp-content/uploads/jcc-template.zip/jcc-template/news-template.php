<?php
/*
Template Name: All posts
*/
?>

<?php get_header(); ?>
	<div id="page">
		<div id="page-bgtop">
			<div id="page-bgbtm">
				<div id="content">					
										<?php
					$debut = 0; //The first article to be displayed
					?>
							<div class="post"> 
						
						<h2 class="title"><?php echo get_the_title(); ?> </h2>
										<?php
$posts = get_posts("numberposts&category=&orderby=post_date&offset=0");
foreach ($posts as $post):
  setup_postdata($post);
?>
					
										<ul id="newslist">
					<li><img src="<?php bloginfo('template_directory'); ?>/images/<?php $categories = get_the_category(); if ( !empty( $categories ) ) { echo $categories[0]->name; }else{ echo 'icon_news_1';} ?>.gif" width="70" height="18" border="0" class="news" /> <?php echo get_the_date(); ?></li>

<p class="newsdesc"> <?php  the_content();?> </p>
</ul>
<?php
endforeach; 
?>
					
					
					
					
					
				
					</div>
					<div style="clear: both;">&nbsp;</div>
				</div>
				<?php get_sidebar(); ?>
				<!-- end #content -->
				
				<div style="clear: both;">&nbsp;</div>
			</div>
		</div>
	</div>
	<!-- end #page -->
</div>


<?php get_footer(); ?>