﻿<div id="sidebar">
<ul dyn-sidebar >
    <li class="static">
		  <h2>商工会目的</h2>
		  <p>本会は、日印間の産業発展、貿易振興、交流促進に協力することを目的とし、併せて関係情報の収集・交換、並びに会員相互の学習と親睦を図ることをその目的とする。</p>
    </li>
    

			<?php if ( !function_exists('dynamic_sidebar')
							|| !dynamic_sidebar() ) : ?> 
			 
			<?php endif; ?>

</ul>
    </div><!-- end .Sidebar  -->
	