/**
 * remove footer
 */
jQuery(document).ready(function($) {
	$('#footer').remove();
});
