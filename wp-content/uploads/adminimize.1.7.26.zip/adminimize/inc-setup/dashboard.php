<?php
/**
 * @package Adminimize
 * @subpackage Dashboard Setup
 * @author Frank Bültge
 */
if ( ! function_exists( 'add_action' ) ) {
	echo "Hi there!  I'm just a part of plugin, not much I can do when called directly.";
	exit;
}

// retrun registered widgets; only on page index/dashboard :(
add_action( 'wp_dashboard_setup', '_mw_adminimize_dashboard_setup', 99 );

function _mw_adminimize_dashboard_setup () {
	global $wp_meta_boxes;
	
	$adminimizeoptions = get_option( 'mw_adminimize' );
	$widgets = _mw_adminimize_get_dashboard_widgets();
	$adminimizeoptions['mw_adminimize_dashboard_widgets'] = $widgets;
	if ( current_user_can( 'manage_options' ) )
		update_option( 'mw_adminimize', $adminimizeoptions );
	
	// exclude super admin
	if ( _mw_adminimize_exclude_super_admin() )
		return NULL;
	
	$user_roles = _mw_adminimize_get_all_user_roles();
	
	foreach ( $user_roles as $role ) {
		$disabled_dashboard_option_[$role] = _mw_adminimize_get_option_value( 
			'mw_adminimize_disabled_dashboard_option_' . $role . '_items'
		);
	}
	//var_dump( get_option('mw_adminimize') );
	foreach ( $user_roles as $role ) {
		if ( ! isset( $disabled_dashboard_option_[$role]['0'] ) )
			$disabled_dashboard_option_[$role]['0'] = '';
	}
	
	foreach ( $user_roles as $role ) {
		$user = wp_get_current_user();
		if ( is_array( $user->roles) && in_array( $role, $user->roles) ) {
			if ( current_user_can( $role ) && is_array( $disabled_dashboard_option_[$role] ) ) {
				foreach( $disabled_dashboard_option_[$role] as $widget ) {
					if ( isset( $widgets[$widget]['context']) )
						remove_meta_box( $widget, 'dashboard', $widgets[$widget]['context'] );
				}
			}
		}
	}
	
}

function _mw_adminimize_get_dashboard_widgets () {
	global $wp_meta_boxes;
	
	$widgets = array();
	if ( isset($wp_meta_boxes['dashboard']) ) {
		foreach( $wp_meta_boxes['dashboard'] as $context => $data ) {
			foreach( $data as $priority => $data ) {
				foreach( $data as $widget => $data ) {
					$widgets[$widget] = array(
						'id' => $widget,
						'title' => strip_tags(
							preg_replace( '/( |)<span.*span>/im', '', $data['title'] )
						),
						'context' => $context,
						'priority' => $priority
					);
				}
			}
		}
	}
	return $widgets;
}
