=== The Future Is Now ===
Contributors: shacker, rboren
Tags: events, posts, time, future
Requires at least: 2.3
Tested up to: 2.6
Stable tag: 1.0

Allow future-time-stamped posts to appear live on your site immediately.

== Description ==

A WordPress plugin aimed primarily at events sites, where you want to be able to timestamp posts in the future but have them appear immediately (by default, WordPress will not display a future timestamped post until its go-live date rolls around). This plugin sets the post_status field to "publish" rather than "future" when publishing a post, even if its timestamp is in the future.

== Installation ==

e.g.

1. Upload `future-post.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Create a new post with a timestamp in the future and notice that appears on your site anyway.

== Note ==

This seemingly simple plugin was graciously written by the magical Ryan Boren when I was facing a deadline. He doesn't have time to maintain/host it, so I agreed to.


