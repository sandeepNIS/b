<?php
/*
Plugin Name: The Future is Now!
Description: Sets future timestamped posts to "publish" rather than "future" upon publish (useful for Events listing sites).
Version: 1.0
Author: Ryan Boren, maintained by Scot Hacker. 
Plugin URI: http://birdhouse.org/software/futurepost
Author URI: http://birdhouse.org/blog

Props to Joost for the name and to Kaf for an alternate 1st approach. 
*/


function setup_future_hook() {
 // Replace native future_post function with replacement
 remove_action('future_post', '_future_post_hook');
 add_action('future_post', 'publish_future_post_now');
}

function publish_future_post_now($id) {
 // Set new post's post_status to "publish" rather than "future."
 wp_publish_post($id);
}

add_action('init', 'setup_future_hook');
?>